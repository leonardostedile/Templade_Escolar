<html>

<head>
    <meta charset="UTF-8">
    <title>Stedile Company</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="style.css" media="screen" />
</head>

<body>
    <h1>
        <center>Tabela<center>
    </h1>

    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#">Navegar</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Alterna navegação">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item active">
                    <a class="nav-link" href="#">Home <span class="sr-only">(Página atual)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Destaques</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Preços</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link disabled" href="#">Desativado</a>
                </li>
            </ul>
        </div>
    </nav>

    <p>Tabela de alguns de nossos clientes...</p>

    <?php

    require './classes/Cliente.php';
    $cliente = new Cliente();
    $listaDeCliente = $cliente->listar();

    ?>

    <table class="table table-sm table-dark">
        <thead>
            <tr>
                <th scope="col">Código</th>
                <th scope="col">Nome</th>
                <th scope="col">Endereço</th>
                <th scope="col">Ações</th>
            </tr>
        </thead>


        <tbody>

            <?php foreach ($listaDeCliente as $c) { ?>
                <tr>
                    <td><?php echo $c['codcli']; ?></td>

                    <td>
                        <a href="editar.php?codcli=<?php echo $c['codcli']; ?>">
                            <?php echo utf8_encode($c['nomcli']); ?>
                        </a>
                    </td>
                    <td><?php echo $c['endcli']; ?></td>

                        <td>
                            <a href="eliminar.php?codcli=<?php echo $c ['codcli'];?>">
                            Eliminar
                            </a>
                        </td>

                </tr>
            <?php } ?>

        </tbody>
    </table>


    <!-- Inicio Footer -->
    <footer class="text-center text-lg-start bg-light text-muted">

        <div class="">
            <p>
                <center>Conecte-se conosco:</center>
            </p>
        </div>




        <!-- Section: Social media -->

        <!-- Section: Links  -->

        <section class="">
            <div class="container text-center text-md-start mt-5">
                <!-- Grid row -->
                <div class="row mt-3">
                    <!-- Grid column -->
                    <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">
                        <!-- Content -->
                        <h6 class="text-uppercase fw-bold mb-4">
                            <i class="fas fa-gem me-3"></i>Stedile Company
                        </h6>
                        <p>
                            Uma Holding dona de várias empresas, tanto no setor têxtil, setor alimenticio e no setor da construção civil, de SC para o Mundo🌎
                        </p>
                    </div>
                    <!-- Grid column -->

                    <!-- Grid column -->
                    <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">
                        <!-- Links -->
                        <h6 class="text-uppercase fw-bold mb-4">
                            Produtos
                        </h6>
                        <p>
                            <a href="#!" class="text-reset">Setor Têxtil</a>
                        </p>
                        <p>
                            <a href="#!" class="text-reset">Empreendimentos</a>
                        </p>
                        <p>
                            <a href="#!" class="text-reset">Setor Alimentos</a>
                        </p>

                    </div>

                    <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
                        <!-- Links -->
                        <h6 class="text-uppercase fw-bold mb-4">
                            Contato
                        </h6>
                        <p><i class="fas fa-home me-3"></i> Brusque-SC, CEP 88353-202 </p>
                        <p>
                            <i class="fas fa-envelope me-3"></i>
                            leonardo_stedile@estudante.sc.senai.br
                        </p>
                        <p><i class="fas fa-phone me-3"></i> +55 (47) 99234-4339</p>
                        <p><i class="fas fa-print me-3"></i> +55 (47) 99197-9902</p>
                    </div>
                    <!-- Grid column -->
                </div>
                <!-- Grid row -->
            </div>
        </section>
        <!-- Section: Links  -->

        <!-- Inicio Copyright -->
        <div class="text-center p-4" style="background-color: rgba(0, 0, 0, 0.05);">
            © 2021 Copyright:
            <a class="text-reset fw-bold" href="https://leonardostedile.wordpress.com/">© Leonardo Stedile 2021</a>
        </div>
        <!-- Final Copyright -->
    </footer>
    <!-- Final Footer -->

</body>

</html>