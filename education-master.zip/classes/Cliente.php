<?php
require 'Conexao.php';

class Aluno {

    private $conexao;

    public function __construct(){
        $con = new Conexao();
        $this->conexao = $con->getConexao();
    }

    public function listar(){

        $sql = 'SELECT * FROM Aluno;';

        $q = $this->conexao->prepare($sql);
        $q->execute();
        return $q;

    }

    public function inserir($nome, $descricao) {
        $sql = 'insert into aluno(nomalu, descalu) values (?, ?);';

        $q = $this->conexao->prepare($sql);

        $q->bindParam(1, $nome);
        $q->bindParam(2, $descricao);

        $q->execute();
    }
    public function eliminar($codalu) {

        $sql = "delete from aluno where codalu = ?";

        $q = $this->conexao->prepare($sql);

        $q->bindParam(1, $codalu);

        $q->execute();

    }
    public function getAluno($codalu){

        $sql = 'select * from Aluno where codalu = ?';

        $q = $this->conexao->prepare($sql);

        $q->bindParam(1, $codalu);

        $q->execute();

        $aluno = [];

        foreach ($q as $c){
            $aluno = $c;

        }

        return $aluno;

    }

    public  function editar($codalu, $nomalu, $descalu){

        $sql = 'update aluno set nomalu = ?, descalu = ? where codalu = ?';

        $q = $this->conexao->prepare($sql);

        $q->bindParam(1, $nomalu);
        $q->bindParam(2, $descalu);
        $q->bindParam(3, $codalu);

        $q->execute();


    }

   

}