<html>

<head>
    <meta charset="UTF-8">
    <title>Stedile Company</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
</head>

<body>

    <?php

    $redirecionar = true;

    if (isset($_GET['codcli'])){
        if (is_numeric($_GET['codcli'])){

            $redirecionar = false;

    require './classes/Cliente.php';
    $cli = new Cliente();
    


    if (isset($_POST['nomcli'])) {

        $cli->editar($_GET['codcli'], $_POST['nomcli'], $_POST['desccli']);

    }

    $cliente = $cli->getCliente($_GET['codcli']);

    }
}

if ($redirecionar){
    header("Location: index.php");
    exit();
}

    ?>

    <?php if (isset($_POST['nomcli'])) { ?>
        <script>
            alert('Cliente atualizado com sucesso!');
        </script>
    <?php } ?>

    <form action="editar.php?codcli=<?php echo $_GET['codcli']; ?>" method="post">


        <div class="form-group">
            <label for="exampleInputPassword1">Nome:</label>
            <input type="text" value="<?php echo $cliente ['nomcli'];?>" name="nomcli" id="nomcli">
        </div>

        <div class="form-group">
            <label for="exampleInputPassword1">Endereço:</label>
            <input type="text" value="<?php echo $cliente ['desccli'];?>" name="desccli" id="desccli">
        </div>

        <button type="submit" class="btn btn-primary">Enviar</button>

    </form>

</body>

</html>